#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "digest.hpp"
#define SERV_TCP_PORT 1111
#define SERV_ADDR "127.0.0.1"

int main()
{
	int s1, s2, x;
	struct sockaddr_in serv_addr, cli_addr;
	char buf[256];
	size_t xx;
	printf("Hi, I am the server\n");
	bzero((char*)&serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = inet_addr(SERV_ADDR);
	serv_addr.sin_port = htons(SERV_TCP_PORT);
	if ((s1 = socket(PF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("socket creation error\n");
		exit(1);
	}
	printf("socket created successfully. socket num is %d\n", s1);
	x = bind(s1, (struct sockaddr*)&serv_addr, sizeof(serv_addr));


	if (x < 0)
	{
		printf("binding failed\n");
		exit(1);
	}
	printf("binding passed\n");
	listen(s1, 5);
	xx = sizeof(cli_addr);
	s2 = accept(s1, (struct sockaddr*)&cli_addr, (socklen_t*)&xx);
	printf("we passed accept. new socket num is %d\n", s2);
	read(s2, buf, 10);
	buf[2] = 0;
	printf("we got request for %s from cli\n", buf);



	std::string key = "secret";
	digest::HMAC<digest::SHA256> hmac(key);
	/*
	printf("[+] I have to send this message, hmac to cli\n");

	char msg[] = "hi there";

	std::string key = "secret";
	std::string data = msg;
	digest::HMAC<digest::SHA256> hmac(key);
	std::string hmacvalue = hmac.add(data).hexdigest();

	
	printf("[+] Send my message, hmac to cli !\n");
	write(s2, msg, 9);
	write(s2, hmacvalue.c_str(), strlen(hmacvalue.c_str()));
	*/

	FILE* file;
	const char* filename = "a.txt";
	size_t fsize = 0, nsize = 0, fpsize = 0;
	size_t fsize2 = 0;
	

	file = fopen(filename, "rb");
	
	int isnull = 0;
	if (file == NULL)
	{
		printf("[-] file not founded!");
		isnull = 1;
		exit(0);
	}

	fseek(file, 0, SEEK_END);
	fsize = ftell(file);
	fseek(file, 0, SEEK_SET);

	char filebuf[6];
	memset(filebuf, 0x00, 6);

	printf("[+] file size : %d\n", fsize);
	

	fpsize = fread(filebuf, sizeof(filebuf), 1, file);

	write(s2, filebuf, sizeof(filebuf));
	printf("[+] a.txt file has sent !\n");

	fclose(file);

	printf("file info : %.25x\n", filebuf);
	printf("file info : %.25x\n", file);
	printf("file size : %d\n", fsize2);

	std::string data = filebuf;

	std::string filehmac = hmac.add(data.c_str()).hexdigest();
	int a = sizeof(filehmac);

	printf("[*] hmac size : %d\n", sizeof(filehmac));
	write(s2, (const void *)filehmac.c_str(), 24);
	
	write(s2, filehmac.c_str(), 64);
	printf("[+] a.txt hmac value has been sent!\n");
	
	printf("[*] hmac : %s\n", filehmac.c_str());
	
	exit(0);

	return 0;
}